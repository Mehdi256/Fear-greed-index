// Dummy settings_service
